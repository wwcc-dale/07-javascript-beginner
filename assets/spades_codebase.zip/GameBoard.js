class GameBoard {
  constructor() {
    this.gameRunner = null;
    // this.setupEventListeners() called manually in app.js or init
  }

  async initialize(gameRunner) {
    this.gameRunner = gameRunner;
    this.clearBoard();
    this.gameRunner.game.gameState.players.forEach((player, i) => {
      document.getElementById(`player-${i}`).querySelector('.player-name').textContent = player.name;
    });
  }

  displayPlayers(players) {
    players.forEach((player, i) => {
      const slot = document.getElementById(`player-${i}`);
      slot.querySelector('.player-score').textContent = player.getScore();
    });
  }

  displayPlayerHand(hand) {
    const handDiv = document.getElementById('player-hand');
    handDiv.innerHTML = '';

    hand.forEach(card => {
      const cardDiv = document.createElement('div');
      cardDiv.className = `card ${card.getSuit().toLowerCase()}`;
      cardDiv.textContent = card.toString().split(' ')[0]; // Just rank
      cardDiv.dataset.card = JSON.stringify({suit: card.getSuit(), rank: card.getRank()});
      handDiv.appendChild(cardDiv);
    });
  }

  // Simplified stub
  async getBidFromUser() {
    return new Promise(resolve => {
      setTimeout(() => resolve(2), 1000);
    });
  }

  async getCardFromUser(validCards) {
    return new Promise(resolve => {
      setTimeout(() => resolve(validCards[0]), 1500);
    });
  }

  updateStatus(round, phase, playerName) {
    document.getElementById('game-status').textContent = `Round ${round} - ${phase}`;
    document.getElementById('current-turn').textContent = `Turn: ${playerName}`;
  }

  addLog(message) {
    const log = document.getElementById('log-content');
    const entry = document.createElement('div');
    entry.className = 'log-entry';
    entry.textContent = new Date().toLocaleTimeString() + ': ' + message;
    log.appendChild(entry);
    log.scrollTop = log.scrollHeight;
  }

  clearLog() {
    document.getElementById('log-content').innerHTML = '';
  }

  clearBoard() {
    document.getElementById('player-hand').innerHTML = '';
    document.getElementById('trick-cards').innerHTML = '';
    this.clearLog();
  }
}
