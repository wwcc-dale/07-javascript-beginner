class AIPlayer extends Player {
  constructor(name) {
    super(name, true);
  }

  getBidDecision(hand) {
    const spadesCount = this.countSuit(hand, 'Spades');
    const highCards = hand.filter(c => c.getValue() >= 11).length;
    const handStrength = spadesCount + highCards;

    if (handStrength >= 8) return 4;
    if (handStrength >= 6) return 3;
    if (handStrength >= 4) return 2;
    return 1;
  }

  getCardDecision(validCards, trick) {
    // Can we win the trick?
    const winningCard = this.findBestWinningCard(validCards, trick);
    if (winningCard) return winningCard;

    // Otherwise dump lowest card
    return this.findLowestCard(validCards);
  }

  findBestWinningCard(validCards, trick) {
    if (trick.length === 0) {
        // Leading: play highest card (simple strategy)
        return validCards.reduce((prev, current) => (prev.getValue() > current.getValue()) ? prev : current);
    }

    for (let card of validCards) {
      if (this.canWinTrick(card, trick)) {
        return card;
      }
    }
    return null;
  }

  canWinTrick(card, trick) {
    if (trick.length === 0) return true;

    const ledSuit = trick[0].getSuit();
    const isSpades = card.getSuit() === 'Spades';

    // Must follow suit if possible (validCards logic handles this availability)
    // If not following suit and not spades, can't win against led suit (unless led wasn't trump)
    // Simplified check:

    // Current winner of the trick so far:
    let currentWinnerValue = -1;
    let currentWinnerSuit = ledSuit;
    let hasSpadesBeenPlayed = false;

    // Find current winning card in the trick
    // trick[0] is index 0.
    // We need to compare against the best card currently in 'trick'

    let bestCard = trick[0];

    for (let i = 1; i < trick.length; i++) {
        const tCard = trick[i];
        if (tCard.getSuit() === 'Spades' && bestCard.getSuit() !== 'Spades') {
            bestCard = tCard;
        } else if (tCard.getSuit() === bestCard.getSuit() && tCard.getValue() > bestCard.getValue()) {
            bestCard = tCard;
        }
    }

    // Now compare our candidate 'card' against 'bestCard'
    if (card.getSuit() === 'Spades' && bestCard.getSuit() !== 'Spades') return true;
    if (card.getSuit() === bestCard.getSuit() && card.getValue() > bestCard.getValue()) return true;

    return false;
  }

  findLowestCard(cards) {
    return cards.reduce((lowest, card) => 
      card.getValue() < lowest.getValue() ? card : lowest
    );
  }

  countSuit(hand, suit) {
    return hand.filter(c => c.getSuit() === suit).length;
  }
}
