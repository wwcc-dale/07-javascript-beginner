class App {
  constructor() {
    this.gameBoard = new GameBoard();
    this.gameRunner = null;
    this.game = null;

    this.setupEventListeners();
  }

  setupEventListeners() {
    document.getElementById('start-game').addEventListener('click', () => {
      this.startNewGame();
    });

    document.getElementById('reset-game').addEventListener('click', () => {
      this.resetGame();
    });

    document.getElementById('clear-log').addEventListener('click', () => {
      this.gameBoard.clearLog();
    });
  }

  async startNewGame() {
    const players = [
      new Player('You', false), // Human placeholder
      new AIPlayer('Bot North'),
      new AIPlayer('Bot East'), 
      new AIPlayer('Bot South')
    ];

    this.game = new SpadesGame(players);
    this.gameRunner = new GameRunner(this.game);
    this.gameRunner.setVerbose(false); 

    // Override log to redirect to UI
    this.gameRunner.log = (msg) => this.gameBoard.addLog(msg);

    await this.gameBoard.initialize(this.gameRunner);
    this.gameBoard.updateStatus(1, 'bidding', 'You');

    await this.gameRunner.playMultipleRounds(4);
    this.gameBoard.addLog('=== GAME COMPLETE ===');
  }

  resetGame() {
    this.gameBoard.clearBoard();
    this.gameBoard.addLog('Game reset. Click "New Game" to play.');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new App();
});
