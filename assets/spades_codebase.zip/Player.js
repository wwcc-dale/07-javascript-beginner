class Player {
  constructor(name, isAI = false) {
    this.name = name;
    this.isAI = isAI;
    this.hand = [];
    this.resetForNewRound();
  }

  addCard(card) {
    this.hand.push(card);
  }

  playCard(card) {
    const index = this.hand.findIndex(c => c.equals(card));
    if (index !== -1) {
      return this.hand.splice(index, 1)[0];
    }
    return null;
  }

  clearHand() {
    this.hand = [];
  }

  setBid(bid) {
    this.bid = bid;
  }

  incrementTricks() {
    this.tricksWon++;
  }

  resetForNewRound() {
    this.hand = [];
    this.bid = null;
    this.tricksWon = 0;
  }

  getScore() {
    return this.score || 0;
  }

  setScore(score) {
    this.score = score;
  }
}
