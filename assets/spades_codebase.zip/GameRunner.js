class GameRunner {
  constructor(game) {
    this.game = game;
    this.verbose = true;
  }

  startGame() {
    this.log("=== New Spades Game ===");
    for (let round = 1; round <= 4; round++) {
      this.playRound();
    }
    this.displayResults();
  }

  playRound() {
    this.log(`--- Round ${this.game.gameState.roundNumber} ---`);
    this.game.startNewRound();

    // Bidding Phase
    this.log("Bidding Phase:");
    this.game.gameState.players.forEach(player => {
        // If AI, get decision. If human, prompt (simulated here)
        let bid = 1; 
        if (player.isAI) {
            bid = player.getBidDecision(player.hand);
        }
        player.setBid(bid);
        this.log(`${player.name} bids ${bid}`);
    });

    // Playing Phase
    for (let trickNum = 1; trickNum <= 13; trickNum++) {
        this.playTrick(trickNum);
    }

    this.game.calculateScores();
    this.displayGameState();
  }

  playTrick(trickNum) {
      this.log(`Trick ${trickNum}:`);
      let trick = [];
      let ledSuit = null;
      let startPlayerIndex = this.game.gameState.currentPlayerIndex;

      for (let i = 0; i < 4; i++) {
          const player = this.game.gameState.getCurrentPlayer();
          let card;

          const validCards = this.getValidCards(player, ledSuit);

          if (player.isAI) {
              card = player.getCardDecision(validCards, trick);
          } else {
              // Simulating human choice for console run (first valid card)
              card = validCards[0]; 
          }

          player.playCard(card);
          trick.push(card);
          if (!ledSuit) ledSuit = card.getSuit();

          this.log(`${player.name} plays ${card.toString()}`);
          this.game.gameState.advanceTurn();
      }

      const winnerRelativeIndex = this.getTrickWinnerIndex(trick, ledSuit);
      // Calculate actual player index from relative offset
      // But wait, advanceTurn moves the index.
      // Correct logic: The winner leads next.
      // We need to track who played what to know who the winner is in the global player list.

      // Let's simplify:
      // The player who started this trick is at 'startPlayerIndex'.
      // The winner is (startPlayerIndex + winnerRelativeIndex) % 4.

      const winnerIndex = (startPlayerIndex + winnerRelativeIndex) % 4;
      const winner = this.game.gameState.players[winnerIndex];
      winner.incrementTricks();
      this.log(`${winner.name} wins the trick!`);

      // Winner leads next
      this.game.gameState.currentPlayerIndex = winnerIndex;
  }

  getValidCards(player, ledSuit) {
      if (!ledSuit) return player.hand;
      const followSuit = player.hand.filter(c => c.getSuit() === ledSuit);
      return followSuit.length > 0 ? followSuit : player.hand;
  }

  getTrickWinnerIndex(trick, ledSuit) {
      let winnerIndex = 0;
      let winningCard = trick[0];

      for (let i = 1; i < trick.length; i++) {
          const card = trick[i];
          if (card.getSuit() === 'Spades' && winningCard.getSuit() !== 'Spades') {
              winningCard = card;
              winnerIndex = i;
          } else if (card.getSuit() === winningCard.getSuit() && card.getValue() > winningCard.getValue()) {
               winningCard = card;
               winnerIndex = i;
          }
      }
      return winnerIndex;
  }

  playMultipleRounds(maxRounds) {
    for (let i = 0; i < maxRounds; i++) {
      this.playRound();
    }
    this.displayResults();
  }

  getGameState() {
    return {
      round: this.game.gameState.roundNumber,
      players: this.game.gameState.players.map(p => ({
        name: p.name,
        score: p.getScore(),
        bid: p.bid,
        tricks: p.tricksWon
      }))
    };
  }

  displayGameState() {
    const state = this.getGameState();
    console.log(`End of Round ${state.round} Scores:`);
    state.players.forEach(p => {
      console.log(`${p.name}: ${p.score} pts (Bid ${p.bid}, Won ${p.tricks})`);
    });
  }

  displayResults() {
    console.log("
=== FINAL RESULTS ===");
    this.game.gameState.players
      .sort((a, b) => b.getScore() - a.getScore())
      .forEach(p => {
        console.log(`${p.name}: ${p.getScore()} points`);
      });
  }

  log(message) {
    if (this.verbose) console.log(message);
  }

  setVerbose(flag) {
    this.verbose = flag;
  }
}
